1. Run ppin.py to generate the PPIN edge list from target.txt as seed node list.
2. Run SPAF_golgi.py to genarate the nodes associated with altered shortest paths of Arf1.   
3. Run CluGo to visualize the pathway enrichment.  
