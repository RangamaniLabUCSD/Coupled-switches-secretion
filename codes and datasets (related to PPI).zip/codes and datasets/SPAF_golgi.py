import networkx as nx
import numpy as np
import itertools
import collections
#F1 = open('diff_path.txt','w')
A=nx.Graph()
B=nx.Graph()
A=nx.read_edgelist("edge_list.txt")
GCC_MSG = max(nx.connected_component_subgraphs(A), key=len)
B=nx.read_edgelist("edge_list.txt")
B.remove_node('CCDC88A')
#B.remove_edge('CCDC88A','NOD2')
GCC_PRM = max(nx.connected_component_subgraphs(B), key=len)
X='ARF1'
EN=[]
for n in GCC_PRM.nodes():
	path_list_msg=[]
	path_list_prm=[]
	all_paths_msg=nx.all_shortest_paths(GCC_MSG,X,n)
	for ix in all_paths_msg:
		path_list_msg.append(ix)
	all_paths_prm=nx.all_shortest_paths(GCC_PRM,X,n)
	for iy in all_paths_prm:
		path_list_prm.append(iy)
	xl=nx.shortest_path_length(GCC_MSG,X,n)
	yl=nx.shortest_path_length(GCC_PRM,X,n)
	T_msg = [tuple(y) for y in path_list_msg]
	T_prm = [tuple(y) for y in path_list_prm]
	U_msg=set(T_msg) - set (T_prm)
	UT_msg = [tuple(y) for y in U_msg]
	U_prm=set(T_prm) - set (T_msg)
	UT_prm = [tuple(y) for y in U_prm]
	for i in UT_msg:
   	  	   for j in T_prm:
			if (len(set(i)^set(j))*1.0/(len(set(i))+len(set(j))-4)*1.0)==1:
				#F6.write('%s\t%s\n'%(node_set[0],node_set[1]))
				#EN.append(node_set[0])
				EN.append(n)
	for i in UT_prm:
   	  	   for j in T_msg:
			if (len(set(i)^set(j))*1.0/(len(set(i))+len(set(j))-4)*1.0)==1:
				#F6.write('%s\t%s\n'%(node_set[0],node_set[1]))
				#EN.append(node_set[0])
				EN.append(n)


FRQ=collections.Counter(EN)
print FRQ
FRQ_L=[]
for i in FRQ:
	FRQ_L.append(FRQ[i])
FRQ_M=np.mean(FRQ_L)
FRQ_S=np.std(FRQ_L)
F7 = open('EN_FRQ_Z_ARF1_2.txt','w')
for i in FRQ:
	F7.write('%s\t%s\t%s\n'%(i,FRQ[i],((FRQ[i]-FRQ_M)/FRQ_S)))
F7.close()
